from sc2.generate_ids import IdGenerator

if __name__ == "__main__":
    id_updater = IdGenerator()
    id_updater.update_ids_from_stableid_json()
