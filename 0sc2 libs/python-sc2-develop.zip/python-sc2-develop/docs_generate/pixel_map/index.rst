.. toctree::
   :maxdepth: 2

****************************
pixel_map.py
****************************

TODO: Replace this with info about this file

.. autoclass:: sc2.pixel_map.PixelMap
   :members: