.. toctree::
   :maxdepth: 2

****************************
score.py
****************************

TODO: Replace this with info about this file

.. autoclass:: sc2.score.ScoreDetails
   :members: