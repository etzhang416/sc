.. toctree::
   :maxdepth: 2

********************************************************
game_data.py
********************************************************

TODO: Replace this with info about this file

.. autoclass:: sc2.game_data.GameData
   :members:
.. autoclass:: sc2.game_data.AbilityData
   :members:
.. autoclass:: sc2.game_data.UnitTypeData
   :members:
.. autoclass:: sc2.game_data.UpgradeData
   :members:
.. autoclass:: sc2.game_data.Cost
   :members:
