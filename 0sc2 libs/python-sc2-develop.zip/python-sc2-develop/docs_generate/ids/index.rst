.. toctree::
   :maxdepth: 2

****************************
ids
****************************

TODO: Replace this with info about this file

.. autoclass:: sc2.ids.ability_id.AbilityId
   :members:
.. autoclass:: sc2.ids.buff_id.BuffId
   :members:
.. autoclass:: sc2.ids.effect_id.EffectId
   :members:
.. autoclass:: sc2.ids.unit_typeid.UnitTypeId
   :members:
.. autoclass:: sc2.ids.upgrade_id.UpgradeId
   :members: