.. toctree::
   :maxdepth: 2

****************************
bot_ai.py
****************************

This basic bot class contains a few helper functions, basic properties and variables to get a simple bot started.

How to use this information is shown in the bot examples (with comments).


.. autoclass:: sc2.bot_ai.BotAI
   :members: