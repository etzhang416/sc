This data comes from dentosals tech tree and is only used to generate the dictionaries in /sc2/dicts/:

https://github.com/BurnySc2/sc2-techtree/tree/master/data

If you see abilities missing, requirements wrong or anything else related to the /sc2/dicts/, please open and write an issue here:
https://github.com/BurnySc2/sc2-techtree/issues/new