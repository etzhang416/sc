.. toctree::
   :maxdepth: 2

****************************
client.py
****************************

TODO: Replace this with info about this file

.. autoclass:: sc2.client.Client
   :members: