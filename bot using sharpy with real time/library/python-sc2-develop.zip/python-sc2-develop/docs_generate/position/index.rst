.. toctree::
   :maxdepth: 2

****************************
position.py
****************************

TODO: Replace this with info about this file

.. autoclass:: sc2.position.Pointlike
   :members:
.. autoclass:: sc2.position.Point2
   :members:
.. autoclass:: sc2.position.Point3
   :members:
.. autoclass:: sc2.position.Size
   :members:
.. autoclass:: sc2.position.Rect
   :members: