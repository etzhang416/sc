import enum


class AirArmy(enum.Enum):
    NoAir = 0
    SomeAir = 1
    Mixed = 2
    AlmostAllAir = 3
    AllAir = 4
