from sharpy.managers.combat2 import GenericMicro


class MicroCarriers(GenericMicro):
    def __init__(self):
        super().__init__()
