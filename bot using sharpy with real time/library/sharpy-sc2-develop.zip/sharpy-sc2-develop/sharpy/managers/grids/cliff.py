import enum


class Cliff(enum.Enum):
    No = 0
    LowCliff = 1
    HighCliff = 2
    BothCliff = 3
